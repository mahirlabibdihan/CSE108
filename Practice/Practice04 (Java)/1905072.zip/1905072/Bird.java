package com.dihu.genus;

import com.dihu.Animal;

public class Bird extends Animal {
    public Bird(String name, int age) {
        super(name, age);
    }
}
