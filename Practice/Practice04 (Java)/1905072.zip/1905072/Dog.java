package com.dihu.species;

import com.dihu.genus.Mammal;
public class Dog extends Mammal {
    public Dog(String name,int age) {
        super(name, age,"Warm-Blooded");
    }
    @Override
    public String toString() {
        return getName()+" is a "+getClass().getSimpleName()+", aged "+getAge();
    }
}
