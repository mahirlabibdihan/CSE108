package com.dihu.genus;

import com.dihu.Animal;

public class Arachnid extends Animal {
    public Arachnid(String name, int age) {
        super(name, age);
    }
}
