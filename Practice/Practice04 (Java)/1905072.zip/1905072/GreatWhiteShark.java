package com.dihu.species;

import com.dihu.genus.Fish;
public class GreatWhiteShark extends Fish{
    public GreatWhiteShark(String name,int age) {
        super(name, age);
    }
    @Override
    public String toString() {
        return getName()+" is a "+getClass().getSimpleName()+", aged "+getAge();
    }
}
