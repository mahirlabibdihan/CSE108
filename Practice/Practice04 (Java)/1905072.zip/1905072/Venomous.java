package com.dihu;
public interface Venomous {
    boolean isLethalToAdultHumans();
}