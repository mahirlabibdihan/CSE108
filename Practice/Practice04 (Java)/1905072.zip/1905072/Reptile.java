package com.dihu.genus;

import com.dihu.Animal;

public class Reptile extends Animal {
    public Reptile(String name, int age) {
        super(name, age);
    }
}
