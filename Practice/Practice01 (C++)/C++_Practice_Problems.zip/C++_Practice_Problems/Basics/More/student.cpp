#include<iostream>

using namespace std;


class Student{
    private:
        int id;
        int level;
        int term;
        double cgpa;
        int departmentCode;

    public:
        Student(){
        }

        Student(int sId,int deptCode){
            //default will be level1 term1
        }
        Student(int sId,int sLevel, int sTerm,int deptCode){

        }

        //setter getter for all private variables

};
