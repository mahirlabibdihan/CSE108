#include<iostream>

using namespace std;

int main(){


    cout<<"Hello c++"<<endl<<"Hello Another c++"<<endl;

    int a=10;
    double b=12.12121;
    float c=12.222;

    cin>>a>>b>>c;

    cout<<a<<b<<c;

    return 0;
}
