#include<stdio.h>

int main(){


    if(int i=0){
        printf("will print");

    }



    for(int i=0;i<1;i++){
        printf("%d\n",&i);
        //printf("Hello c in c++\n");
    }

    for(int i=0;i<1;i++){
        printf("%d\n",&i);
        //printf("Hello c in c++\n");
    }

    return 0;
}
