package com.dihu.classes;

import java.util.ArrayList;
import java.util.List;

public class Club {
    private final static int MAX_PLAYER_COUNT = 7;      // Limit of maximum player in a club
    private String name;    // Name of the club
    private List<Player> playerList;    // List of players under a club

    public Club() {
        playerList = new ArrayList();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Player> getPlayerList() {
        return playerList;
    }

    public void addPlayer(Player p) {
        playerList.add(Player.copy(p));     // Adding player to the list
    }

    public boolean isFull() {
        return playerList.size() == MAX_PLAYER_COUNT;
    }

    public List<Player> getMaxSalaryPlayer() {
        List<Player> searchedPlayers = new ArrayList();
        double max = 0;

        // Finding the max salary
        for (Player p : playerList) {
            max = Math.max(p.getWeeklySalary(), max);
        }

        // Searching for the players with max salary
        for (Player p : playerList) {
            if (p.getWeeklySalary() == max) {
                searchedPlayers.add(p);
            }
        }
        return searchedPlayers;
    }

    public List<Player> getMaxHeightPlayer() {
        List<Player> searchedPlayers = new ArrayList();
        double max = 0;

        // Finding the max height
        for (Player p : playerList) {
            max = Math.max(p.getHeight(), max);
        }

        // Searching for the players with max height
        for (Player p : playerList) {
            if (p.getHeight() == max) {
                searchedPlayers.add(p);
            }
        }
        return searchedPlayers;
    }

    public List<Player> getMaxAgePlayer() {
        List<Player> searchedPlayers = new ArrayList();
        int max = 0;
        // Finding the max age
        for (Player p : playerList) {
            max = Math.max(p.getAge(), max);
        }

        // Searching for the players with max age
        for (Player p : playerList) {
            if (p.getAge() == max) {
                searchedPlayers.add(p);
            }
        }
        return searchedPlayers;
    }

    public double getTotalYearlySalary() {
        double total = 0;

        // Adding the weekly salary of all players
        for (Player p : playerList) {
            total += p.getWeeklySalary();
        }
        return 365 * total / 7;     // Total yearly salary
    }

    public Player searchPlayerByNumber(int number){
        for (Player p : playerList){
            if(p.getNumber()==number){
                return p;
            }
        }
        return null;
    }

}
